﻿namespace P03_FootballBetting.Data.Models 
{
    public enum PredictionType
    {
        AwayTeam,
        HomeTeam,
        Draw
    }
}